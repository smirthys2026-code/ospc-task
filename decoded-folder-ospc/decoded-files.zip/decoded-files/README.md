# Decoded Files
Unofficial fan hub for Saravanan Decodes. Plain HTML/CSS/JS, no build step.

## Get a YouTube Data API v3 key
1. Open Google Cloud Console and create a project.
2. APIs & Services > Library > enable **YouTube Data API v3**.
3. APIs & Services > Credentials > Create credentials > **API key**.

## Generate the full video list
Mac/Linux:
```
YT_API_KEY=yourkey node fetch-videos.js
```
Windows PowerShell:
```
$env:YT_API_KEY="yourkey"; node fetch-videos.js
```
Commit the generated `videos.json`. **Do NOT commit your key.**

## Supabase
Set `SUPABASE_URL` and `SUPABASE_KEY` (anon key) at the top of `script.js`.

## Deploy
Upload the folder to Netlify (drag and drop) or push to GitHub and enable Pages. Add `assets/og.png` (1200x630) for share previews.

## Refresh the list later
Re-run the script, commit the new `videos.json`, redeploy.
