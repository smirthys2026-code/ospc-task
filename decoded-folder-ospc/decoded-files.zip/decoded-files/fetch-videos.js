// Run: node fetch-videos.js  (Node 18+, needs env var YT_API_KEY)
const fs = require("fs");
const KEY = process.env.YT_API_KEY;
const API = "https://www.googleapis.com/youtube/v3/";

async function get(path) {
  const r = await fetch(API + path + "&key=" + KEY);
  const j = await r.json();
  if (!r.ok) {
    const reason = j.error && j.error.errors && j.error.errors[0] && j.error.errors[0].reason;
    if (reason === "quotaExceeded") throw new Error("YouTube API quota exceeded. Try again tomorrow.");
    throw new Error("API error " + r.status + ": " + ((j.error && j.error.message) || "unknown"));
  }
  return j;
}

(async () => {
  if (!KEY) { console.error("Missing YT_API_KEY. See README.md."); process.exit(1); }
  try {
    console.log("Resolving channel @saravanandecodes ...");
    const ch = await get("channels?part=contentDetails&forHandle=@saravanandecodes");
    if (!ch.items || !ch.items.length) throw new Error("Channel handle not found. Check the handle.");
    const uploads = ch.items[0].contentDetails.relatedPlaylists.uploads;
    console.log("Uploads playlist:", uploads);
    let out = [], token = "", page = 0;
    do {
      const d = await get("playlistItems?part=snippet&maxResults=50&playlistId=" + uploads + (token ? "&pageToken=" + token : ""));
      for (const it of d.items) {
        const t = it.snippet.title;
        if (t === "Private video" || t === "Deleted video") continue;
        out.push({ id: it.snippet.resourceId.videoId, title: t, publishedAt: it.snippet.publishedAt });
      }
      token = d.nextPageToken; page++;
      console.log("Page " + page + ": " + out.length + " videos so far");
    } while (token);
    out.sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
    fs.writeFileSync("videos.json", JSON.stringify(out, null, 2));
    console.log("Done. Wrote " + out.length + " videos to videos.json");
  } catch (e) { console.error("Failed:", e.message); process.exit(1); }
})();
